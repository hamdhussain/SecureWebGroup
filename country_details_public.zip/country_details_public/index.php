<?php
/** index.php
	* PHP program to demonstrate the usage of a soap server
	*/

	include 'country_details/bootstrap.php';