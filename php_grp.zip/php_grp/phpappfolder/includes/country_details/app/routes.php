<?php
/**
	* routes.php
	*
	* routes to features
	*
	* Author: CF Ingrams
	* Email: <cfi@dmu.ac.uk>
	* Date: 18/10/2015
	*
	*/

require 'routes/homepage.php';
require 'routes/processcountrydetails.php';